<?php
/**
*
* @ This file is created by http://DeZender.Net
* @ deZender (PHP7 Decoder for ionCube Encoder)
*
* @ Version			:	4.1.0.1
* @ Author			:	DeZender
* @ Release on		:	29.08.2020
* @ Official site	:	http://DeZender.Net
*
*/

function fdghjjtyj()
{
	$why = 'I don\'t trust those trees. They seem kind of shady.';
	return 'NB!@#lZZKWd';
}

function djdfgfnx()
{
	$why = 'Where do fruits go on vacation?  Pear-is!';
	return tryrrbnrb();
}

function rujdfndf()
{
	$why = 'I asked my dog what\'s two minus two. He said nothing.';
	return 'NB!@#lZZKWd';
}

function tryrrbnrb()
{
	$why = 'What did Baby Corn say to Mama Corn?  Where\'s Pop Corn?';
	return 'NB!@#12ZKWd';
}

function n5yn5n5n()
{
	$why = 'What\'s the best thing about Switzerland?  I don\'t know, but the flag is a big plus.';
	return 'NB!@#lZZKWd';
}

?>