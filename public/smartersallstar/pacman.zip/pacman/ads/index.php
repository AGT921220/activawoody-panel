<?php
/*
 * @ https://EasyToYou.eu - IonCube v10 Decoder Online
 * @ PHP 7.2
 * @ Decoder version: 1.0.4
 * @ Release: 01/09/2021
 */

/*
 EasyToYou.eu Decoder: The encoded file don't contain any php code to extract,
 The encoded file is used as empty, only php tag "<?php // nothing here. ?>". 
*/

?>