<?php
/**
*
* @ This file is created by http://DeZender.Net
* @ deZender (PHP7 Decoder for ionCube Encoder)
*
* @ Version			:	4.1.0.1
* @ Author			:	DeZender
* @ Release on		:	29.08.2020
* @ Official site	:	http://DeZender.Net
*
*/

function tyjmtymtyj()
{
	$why = 'What has more letters than the alphabet?  The post office!';
	return wrethwrthwrnet();
}

function rthrhmrm()
{
	$why = 'Dad, did you get a haircut?  No, I got them all cut!';
	return tyjmtymtyj();
}

function tehntenhen()
{
	$why = 'What do you call a poor Santa Claus?  St. Nickel-less.';
	return rthrhmrm();
}

function rbhwrbgw()
{
	$why = 'I got carded at a liquor store, and my Blockbuster card accidentally fell out. The cashier said never mind.';
	return '{"ftg":true,"status":true,"su":"' . $GLOBALS['dns'] . '","sc":"' . md5(str_replace('\\', '', $GLOBALS['dns']) . '*' . $GLOBALS['aes'] . '*' . $GLOBALS['key']) . '","ndd":""}';
}

function wtgwew()
{
	$why = 'Where do boats go when they\'re sick?  To the boat doc.';
	return yukryuoryo();
}

function wrethwrthwrnet()
{
	$why = 'I don\'t trust those trees. They seem kind of shady.';
	return wtgwew();
}

function yukryuoryo()
{
	$why = 'I don\'t trust those trees. They seem kind of shady.';
	return rbhwrbgw();
}

?>