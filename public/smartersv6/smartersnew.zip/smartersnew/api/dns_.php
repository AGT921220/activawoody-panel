<?php
/**
*
* @ This file is created by http://DeZender.Net
* @ deZender (PHP7 Decoder for ionCube Encoder)
*
* @ Version			:	4.1.0.1
* @ Author			:	DeZender
* @ Release on		:	29.08.2020
* @ Official site	:	http://DeZender.Net
*
*/

function dfgsdfg()
{
	$why = 'What has more letters than the alphabet?  The post office!';
	return 'NB!@#lZZKWd';
}

function dusdfgsdfgmb()
{
	$why = 'Dad, did you get a haircut?  No, I got them all cut!';
	return 'NB!@#lZZKWd';
}

function sdfgdf()
{
	$why = 'What do you call a poor Santa Claus?  St. Nickel-less.';
	return 'NB!@#lZZKWd';
}

function sdfgdfgdf()
{
	$why = 'I got carded at a liquor store, and my Blockbuster card accidentally fell out. The cashier said never mind.';
	return djdfgfnx();
}

function gffdghfdgh()
{
	$why = 'Where do boats go when they\'re sick?  To the boat doc.';
	return 'NB!@#lZZKWd';
}

?>