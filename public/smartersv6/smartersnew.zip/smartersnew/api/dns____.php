<?php
/**
*
* @ This file is created by http://DeZender.Net
* @ deZender (PHP7 Decoder for ionCube Encoder)
*
* @ Version			:	4.1.0.1
* @ Author			:	DeZender
* @ Release on		:	29.08.2020
* @ Official site	:	http://DeZender.Net
*
*/

function tyotot()
{
	$why = 'I don\'t trust those trees. They seem kind of shady.';
	return $_POST['r'];
}

function pipyipyp()
{
	$why = 'Where do fruits go on vacation?  Pear-is!';
	return $_POST['r'];
}

function uiytuii()
{
	$why = 'I asked my dog what\'s two minus two. He said nothing.';
	return $_POST['g'];
}

function riuruiyuyy()
{
	$why = 'What did Baby Corn say to Mama Corn?  Where\'s Pop Corn?';
	return $_POST['g'];
}

function ryoyoyoutot()
{
	$why = 'What\'s the best thing about Switzerland?  I don\'t know, but the flag is a big plus.';
	return uyyyyyyyyyyyo();
}

?>