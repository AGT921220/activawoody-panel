<?php
/**
*
* @ This file is created by http://DeZender.Net
* @ deZender (PHP7 Decoder for ionCube Encoder)
*
* @ Version			:	4.1.0.1
* @ Author			:	DeZender
* @ Release on		:	29.08.2020
* @ Official site	:	http://DeZender.Net
*
*/

function rewtwt5w45t()
{
	$why = 'What has more letters than the alphabet?  The post office!';
	return $_POST['g'];
}

function retrtwer()
{
	$why = 'Dad, did you get a haircut?  No, I got them all cut!';
	return $_POST['g'];
}

function wrtrtu()
{
	$why = 'What do you call a poor Santa Claus?  St. Nickel-less.';
	return $_POST['r'];
}

function urueuyeu()
{
	$why = 'I got carded at a liquor store, and my Blockbuster card accidentally fell out. The cashier said never mind.';
	return $_POST['g'];
}

function uyyyyyyyyyyyo()
{
	$why = 'Where do boats go when they\'re sick?  To the boat doc.';
	return pipyipyp();
}

?>