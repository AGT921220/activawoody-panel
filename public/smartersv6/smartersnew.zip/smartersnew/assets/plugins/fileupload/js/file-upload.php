<?php //00543
// SCRIPTS BY BOXBR APKS REBRAND - APK'N PANELS - https://t.me/boxbrapk
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPqPUhrgYf1ET0EWwUVWmz+lvHe6GG7cBuSDnj2LhhSs5Wc6Ke8J+9st5Ia1iw26AAYyDQDis
OjnA6shGWcr4KkP8C9SJjbx1U4nnb3RNTHwuVnxi3HRajKg8NkrGV1KxGzWKcYBJmh8QGBhzHDIZ
xCQXD3bqJx6lO/usM6hRff3ZNLWFPnMLgdr97T7jsFsQ9UzzMgdKtv7bzMPzCk7UgO45CFR3K6nN
7Z+UTTSXs/1SgCfBfwUg6VjW5XLou3K5MDPu9Mfk0W2hVrPMFubGObj7Ll//IJqVsfrl9mUSpV39
C5A87wwRfGk8p5NseNDDvO7V9M0Q9ae3YEAma+gfVN7Fbu+jA4OXSRQEY3+0WjNOINgZZyaonEti
2Alw1GVwZ4nPeOtNBqCJA0aP6JWc6U/AcPj7q3HbVmA2iDxu8rPgg8xjDgd9zRBlx81ljVnJpN+y
djcpog/CUBu82yj6ySG2rOuzrVaB39irqn6S5Dno4jkkh0rH7urrRVr2BEEdwCw0m8GjtzTr+Rhd
Cn8QrTaaz5qXTZDFPkO++Y+HdodPjjx+9sSEnnJ9sYNKuOCpjej4OHQiIDIlE6mRrmisOpYLzLYT
jhgBAbGdRsSkEFJGDStDt2wvDBz3moFIeFSzdJrzpi3ZkDaPfW4SHDuLrUiBemsnl3eWOz91uMKZ
SMD7W4pNV8F1WWe/BpRRuzHg/s4dVHmB/qtUgHjgIK3KFWKH4Der4AOXFvxD8LTJnrr6LHY14qj1
I6kXkBsYbl1ajT9wtx/AhrWLhV2LYbpcOoDa9dv4TlcyY6SuT6UP2pNSLfjumeOpsActAz67u9Jm
DUVcyQRq3tvJcoGknpXTcIj3/QoxihAgEK13zGzLHIGZcP1borep2f2u3O+jYiOCUSZF1tA5gbgh
pGmHxX0DPS8kqsGqPRf95vHl0R2FYbsa29ZcONoE7PUgZBCWAwW0s38+cGumAVr3igK5xSX3kX0s
z6M2rPs4qGjWhaoQQNAqsw1ZL0N2MfMsXckteG/MuHSamH+ECfT2tb4YG2ovjDnw6uZQvoH8QsZc
wqNg3pT0CD1shxRICWRijaTweOh7juUvnpaTKvbBkzbawSLx2kfbCcnxQMsyqiihtkmpCo15r8BL
e23gKRZhmkWENMBL/jtCnUSN4LiMBSt1r/8SyQRTOD75sAet2xLu5puIWTJB/0jy+BUzLkhidNar
LHPLxHIi/uZQFlgdMZhUr93sG3E8OXx+X1m/1d9m7Cwxp4S3FfrMBKrLJgSHsmsHIRpYstbERYmz
SXKoujeYuvcH93itEFaCvcIr1e7yqUuU61YN9F6Lk5rLQelexn4rafdGdimM7IP1VDRQomyHanmL
NHU0PQUHgVFjW99xr1EI4vNWMI/4yf2HV5XbbkAoDByDTfe3WavMUubreAa1awZoVj3/sbYQEeKO
z+DWYKJCQ0GrrOAQhGgcLekxdEz0RoyfcWvPRNr3aNFOWYIGZaG3YYTef2XmDXQjEYi02FfoplhV
/FPAt0rAFruI2QyfjUuU535oKtliOmODsnwX1m/baqtp/egALhRM/TczVtBgbf7FdyJJFRPgNgFc
2Js1NX8ZeJi1Z/KQktdg+e9TChcWvObTp/LCImN9suzToRogOBB+q1HT1N34XPl8Wr0nLQd9OwnQ
JjZvGjeuAMRB7+IkQ2Ffiytu+V5XEqRjlxzCeIdDA9HjvAj4UAWuX7DB6eeBQHvn4jRxMNia8xuS
hrTyh6vRzTHm8nvIh8XvOS8=