<?php //00543
// SCRIPTS BY BOXBR APKS REBRAND - APK'N PANELS - https://t.me/boxbrapk
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo("Site error: the ".(php_sapi_name()=='cli'?'ionCube':'<a href="http://www.ioncube.com">ionCube</a>')." PHP Loader needs to be installed. This is a widely used PHP extension for running ionCube protected PHP code, website security and malware blocking.\n\nPlease visit ".(php_sapi_name()=='cli'?'get-loader.ioncube.com':'<a href="http://get-loader.ioncube.com">get-loader.ioncube.com</a>')." for install assistance.\n\n");exit(199);
?>
HR+cPrHZdFGkoMJxZDS9roYZMo9bmAhGuBWj7jTmbNQ98kbb4ZFHopjexX+VkD7VaKyQnwjzqtXt
+aG+x5s52Fxpihy5y3sYq7MbMJLmjoKhN0mhxaUms74gK8U83rvaLkUn+0wp7eJYdLpGVz7WOaCP
rX8MrPAisHGNSvPUbd+bU0p2vPYe7wrJ2nSQgDK07ctxGONhE4GME60N4rDT8TcBlZq8+Mx5XaSP
aN+aPR/IV/9aUoloRvEHQ1Bpv6fq3XwVxukBHtmfGjG+nz5b8soEuj7CpHAbNBTpP0k9EDKsHfXk
nMwElprDCD4IU46ZgA5qAQ5nxxh3E01C2kyJB8JaxHcjAYk5ur4jFdJPwUlAJcwchiBkYyHXTODS
w18nyuF+YBuHi1lFmQtAZzye6I2CfXYRjHB3uaEAaHbWJjNXFdZ/gScplF8e5RQX6W34P2NjOsyp
Vw8k3mVwumPlSfbdOi0QcwVdz1Xa3Qbb7AF6c8iMND8IazTPU/zx27TKXS/f3EcvmG5NgfjmxTBU
UH/KLdNDIXS9PjpmIWzfJIg9BSlRzvA+jdiopC7ZGfDC1LVC0Sk7DiY7gvKLMRNWWJawZeot8rgJ
kU0n25ZHWUtxhdA3wXahOmoFMwr1Y5a/U+/WKLNHEj1PnGD1/TJ4xDObPzPAkhSTaQcAUNn2U6J8
0gabXfzbywOaC487De6mwAOXifvsOITz70l/JTwf6sf9GDG+1KeE6NUfIDlAJcxYuLD7NKPR7Ova
A8Rsa1L4OXpZq37cPd0g7Ij0Iut1VtVXP3w4c+a6GCHNUcCdpAxwgQ6I1XoDqsMXvwnOduR7AU6d
LvUAuWPaQbvCkHRUJd0pYz9OUPd2kCLyJfxHgUvWwp/vg24paewqaJ5FAm==