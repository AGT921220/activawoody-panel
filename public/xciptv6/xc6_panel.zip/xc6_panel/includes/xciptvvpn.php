<div class="row mb-4">
    <div class="col-lg-12 col-md-12 mb-md-0">
        <div class="card">
            <div class="card-header pb-0">
                <div class="row">
                    <div class="col-lg-6 col-7">
                        <h6>XCIPTV</h6>
                    </div>
                </div>
            </div>
            <div class="card-body px-0 pb-2">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12 col-lg-12 col-md-12 d-flex flex-column ms-auto me-auto ms-lg-auto me-lg-12">
                            <div class="card card-plain">
                                <div class="card-body" style="text-align: center;">
                                <span class="text" style="text-align:center"><b>XCIPTV V6.0</b> is the latest version of XCIPTV however was released without VPN support, this 6.0 802 version is fully nulled, includes VPN and works with this version of OnePanel.
                                <br>The app name check has been removed so this can be rebranded as you like.<br><b>£25</b> for the APK<br>
                                <a href="https://t.me/AndyHax">Get in touch for more details.</a></span><br>
                                <img style="width:100%;" src="assets/img/xcv6/1.jpg"/>
                                <img style="width:100%;" src="assets/img/xcv6/2.jpg"/>
                                <img style="width:100%;" src="assets/img/xcv6/3.jpg"/>
                                <img style="width:100%;" src="assets/img/xcv6/4.jpg"/>
                                <img style="width:100%;" src="assets/img/xcv6/5.jpg"/>
                                <img style="width:100%;" src="assets/img/xcv6/6.jpg"/>
                                <img style="width:100%;" src="assets/img/xcv6/7.jpg"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>