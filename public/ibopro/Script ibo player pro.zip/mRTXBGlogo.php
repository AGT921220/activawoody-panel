<strong>FEITO!</strong>

<?php
$var = "<script>javascript:history.back(-2)</script>";
echo $var;
?>